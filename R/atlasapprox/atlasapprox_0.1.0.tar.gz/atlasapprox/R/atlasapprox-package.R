# docs as of Google's R style guide
